import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>
        This was an amazing Bootcamp taken up by Shaurya Sinha. We learnt
        everything from scratch including Javascript, React.js, HTMl.
      </p>
    </div>
  );
}

export default Note;
